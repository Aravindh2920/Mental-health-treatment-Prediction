from flask import Flask, render_template, request
import joblib
import os
import numpy as np
import pickle

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("home.html")


@app.route("/result", methods=['POST', 'GET'])
def result():
    gender = int(request.form['age'])
    age = int(request.form['gender'])
    hypertension = int(request.form['family_history'])
    heart_disease = int(request.form['benifits'])
    ever_married = int(request.form['care_options'])
    work_type = int(request.form['Anonymity'])
    Residence_type = int(request.form['leave'])
    avg_glucose_level = float(request.form['work_interfere'])

    x = np.array([gender, age, hypertension, heart_disease, ever_married, work_type, Residence_type,
                  avg_glucose_level]).reshape(1, -1)

    model = pickle.load(open("model.pkl", 'rb'))

    prediction = model.predict(x)

    prediction = prediction[0]

    # for No Stroke Risk
    if prediction == 0:
        return render_template('norish.html')
    else:
        return render_template('risk.html')


if __name__ == "__main__":
    app.run(debug=True)